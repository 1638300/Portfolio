﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2PROF
{
  // Les divers types d'éléments du jeu Pacman
  public enum PacmanElement
  {
   None,
   Wall,
   Ghost,
   Pacman,
   Pill,
   SuperPill,
   GhostCage
  }
}

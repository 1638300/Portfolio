﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2PROF
{
  //résultat de la fin de la partie
  public enum EndGameResult
  {
    NotFinished,
    Win,
    Losse,
  }
}

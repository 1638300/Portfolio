﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2PROF
{
  /// <summary>
  /// L'algorithme de recherche 
  /// de chemins des fantômes
  /// </summary>
  public static class PathFinder
  {
    // <YGibeau>
    /// <summary>
    /// Initialise le tableau des coûts de déplacements, Le tableau est 
    /// initialisé à int.MaxValue partout sauf à l'endroit où se trouve le
    /// pacman où le tableau est initialisé à 0.
    /// </summary>
    /// <param name="aGrid">La grille du jeu: pour connaitre les dimensions attendues</param>
    /// <param name="fromX">La position du pacman en colonne</param>
    /// <param name="fromY">La position du pacman en ligne</param>
    /// <returns>Le tableau initialisé correctement</returns>
    public static int[,] InitCosts(Grid aGrid, int fromX, int fromY)
    {
      int[,] distances = new int[aGrid.Height, aGrid.Width];

      for (int i = 0; i < distances.GetLength(0); i++)
      {
        for (int j = 0; j < distances.GetLength(1); j++)
        {
          distances[i, j] = int.MaxValue;
        }
      }

      distances[fromY, fromX] = 0;

      return distances;
    }

    /// <summary>
    /// Calcule le nombre de déplacements requis pour aller de la position (fromX, fromY)
    /// vers la position (toX, toY). 
    /// <param name="aGrid">La grille du jeu: pour connaitre les positions des murs</param>
    /// <param name="fromX">La position de départ en colonne</param>
    /// <param name="fromY">La position de départ en ligne</param>
    /// <param name="toX">La position cible en colonne</param>
    /// <param name="toY">La position cible en ligne</param>
    /// <param name="distances">Le tableau des coûts à remplir</param>
    /// <remark>Typiquement, la position (fromX, fromY) est celle du fantôme tandis 
    /// que la position (toX, toY) est celle du pacman.</remark>
    /// <remark>Cette méthode est récursive</remark>
    /// </summary>
    public static int[,] ComputeCosts(Grid aGrid, int fromX, int fromY, int toX, int toY, int[,] distances )
    {
      if (fromX != toX || fromY != toY)
      {
        //  Vérification en Haut (fromY-1)
        if (fromY - 1 >= 0 && aGrid.GetGridElementAt(fromY - 1, fromX) != PacmanElement.Wall && distances[fromY -1, fromX] > distances[fromY, fromX]+1 )
        {
          //Déplacement
          distances[fromY - 1, fromX] = distances[fromY, fromX] + 1;

          ComputeCosts(aGrid, fromX, fromY - 1, toX, toY, distances);
        }
        //Vérification à gauche (fromX - 1)
        if (fromX - 1 >= 0 && aGrid.GetGridElementAt(fromY, fromX - 1) != PacmanElement.Wall && distances[fromY, fromX-1] > distances[fromY, fromX]+1 )
        {
          //Déplacement
          distances[fromY, fromX - 1] = distances[fromY, fromX] + 1;

          ComputeCosts(aGrid, fromX - 1, fromY, toX, toY, distances);         
        }
        //Vérification en bas (fromY + 1)
        if (fromY + 1 < aGrid.Height && aGrid.GetGridElementAt(fromY + 1, fromX) != PacmanElement.Wall && distances[fromY + 1 , fromX] > distances[fromY, fromX]+1 )
        {
          //Déplacement
          distances[fromY + 1, fromX] = distances[fromY, fromX] + 1;

          ComputeCosts(aGrid, fromX , fromY + 1, toX, toY, distances);          
        }
        //Vérification à droite (fromX + 1)
        if (fromX + 1 < aGrid.Width && aGrid.GetGridElementAt(fromY, fromX + 1) != PacmanElement.Wall && distances[fromY, fromX + 1] > distances[fromY, fromX]+1 )
        {
          //Déplacement
          distances[fromY, fromX + 1] = distances[fromY, fromX] + 1;

          ComputeCosts(aGrid, fromX + 1, fromY, toX, toY, distances);          
        }
      }

      return distances;
    }
    //</YGibeau>
    
    //<ASirois>
    /// <summary>
    /// Détermine le premier déplacement nécessaire pour déplacer un objet de la position (fromX, fromY)
    /// vers la position (toX, toY). 
    /// <param name="aGrid">La grille du jeu: pour connaitre les positions des murs</param>
    /// <param name="fromX">La position de départ en colonne</param>
    /// <param name="fromY">La position de départ en ligne</param>
    /// <param name="toX">La position cible en colonne</param>
    /// <param name="toY">La position cible en ligne</param>
    /// <remark>Typiquement, la position (fromX, fromY) est celle du fantôme tandis 
    /// que la position (toX, toY) est celle du pacman.</remark>
    /// <returns>La direction dans laquelle on doit aller. Direction.None si l'on
    /// est déjà rendu ou Direction.Undefined s'il est impossible d'atteindre la cible</returns>
    /// </summary>
    public static Direction FindShortestPath(Grid aGrid, int fromX, int fromY, int toX, int toY)
    {
      if (fromX == toX && fromY == toY || aGrid.GetGridElementAt(toY, toX) == PacmanElement.Wall || aGrid.GetGridElementAt(fromY, fromX) == PacmanElement.Wall)
      {
        return Direction.None;
      }
      else if( toX < 0 || toY < 0)
      {
        return Direction.Undefined;
      }
      else
      {
        int[,] distances = InitCosts(aGrid, fromX, fromY);

        distances = ComputeCosts(aGrid, fromX, fromY, toX, toY, distances);

        return RecurseFindDirection(distances, toX, toY);
      }
    }

    

    /// <summary>
    /// Parcourt le tableau de coûts pour trouver le premier déplacement requis pour aller de la position (fromX, fromY)
    /// vers la position (toX, toY). 
    /// <param name="costs">Le tableau des coûts prédédemment calculés</param>
    /// <param name="targetX">La position cible en colonne</param>
    /// <param name="targetY">La position cible en ligne</param>
    /// <remark>Typiquement, la position (targetX, targetY) est celle du pacman.</remark>
    /// <remark>Cette méthode est récursive</remark>
    /// </summary>
    /// <returns>La direction dans laquelle on doit aller. Direction.None si l'on
    /// est déjà rendu ou Direction.Undefined s'il est impossible d'atteindre la cible</returns>
    public static Direction RecurseFindDirection(int[,] distances, int targetX, int targetY)
    {

      //Direction Nord (Y-1)
      if (targetY > 0)
      {
        if (distances[targetY - 1, targetX] == 0)
        {
          return Direction.South; //Return direction inverse  Nord --> Sud
        }
        else if (distances[targetY - 1, targetX] == distances[targetY, targetX] - 1)
        {
          return RecurseFindDirection(distances, targetX, targetY - 1);
        }
      }
      
      //Direction Sud (Y+1)
      if (targetY < distances.GetLength(0) - 1)
      {
        if (distances[targetY + 1, targetX] == 0)
        {
          return Direction.North; //Return direction inverse Sud --> Nord
        }
        else if (distances[targetY + 1, targetX] == distances[targetY, targetX] - 1)
        {
          return RecurseFindDirection(distances, targetX, targetY + 1);
        }
      }

      //Direction Ouest (X-1)
      if (targetX > 0)
      {
        if (distances[targetY, targetX - 1] == 0)
        {
          return Direction.East; //Return direction inverse  Ouest --> Est
        }
        else if (distances[targetY, targetX - 1] == distances[targetY, targetX] - 1)
        {
          return RecurseFindDirection(distances, targetX - 1, targetY);
        }
      }

      //Direction Est (X+1)
      if (targetX < distances.GetLength(1) - 1)
      {
        if (distances[targetY, targetX + 1] == 0)
        {
          return Direction.West; //Return direction inverse Est --> Ouest
        }
        else if (distances[targetY, targetX + 1] == distances[targetY, targetX] - 1)
        {
          return RecurseFindDirection(distances, targetX + 1, targetY);
        }
      }
      
        return Direction.None;
      
    }
    //</ASirois>
  }
}

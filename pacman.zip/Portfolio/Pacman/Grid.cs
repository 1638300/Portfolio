﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
namespace TP2PROF
{
  /// <summary>
  /// Grille du jeu avec 
  /// les informations sur 
  /// toutes les positions 
  /// initiales
  /// </summary>
  public class Grid
  {
    /// <summary>
    /// Grille logique du jeu.
    /// Tableau 2D de PacmanElement
    /// </summary>  
    // A compléter
    PacmanElement[,] grid;
    /// <summary>
    /// Position de la cage des fantômes
    /// </summary> 
    Vector2i positionCageFantome;

    /// <summary>
    /// Accesseur du numéro de la ligne où se trouve la cage à fantômes
    /// Propriété C#
    /// </summary>
    // A compléter
    public int GhostCagePositionRow
    {
    get { return positionCageFantome.Y; }
    }

    /// <summary>
    /// Accesseur du numéro de la colonne où se trouve la cage à fantômes
    /// Propriété C#
    /// </summary>
    // A compléter
    public int GhostCagePositionColumn
    {
      get { return positionCageFantome.X; }
    }

    /// <summary>
    /// Position originale du pacman
    /// Propriété C#
    /// </summary>
    // A compléter
    Vector2i positionPacman;
    /// <summary>
    /// Accesseur du numéro de la ligne où se trouve le pacman au début
    /// Propriété c#
    /// </summary>
    // A compléter
    public int PacmanOriginalPositionRow
    {
    get { return positionPacman.Y; }
    }

    /// <summary>
    /// Accesseur du numéro de la colonne où se trouve le pacman au début
    /// Propriété C#
    /// </summary>
    // A compléter
    public int PacmanOriginalPositionColumn
    {
      get { return positionPacman.X; }
    }

    /// <summary>
    /// Accesseur de la hauteur
    /// Propriété C#
    /// </summary>
    public int Height
    {
    get { return grid.GetLength(0); }
    }

    /// <summary>
    /// Accesseur de la largeur
    /// Propriété C#
    /// </summary>
    public int Width
    {
      get { return grid.GetLength(1); }
    }


    /// <summary>
    /// Constructeur sans paramètre
    /// </summary>
    public Grid()
    {
      positionPacman = new Vector2i(-1, -1);
      positionCageFantome = new Vector2i(-1, -1);
      grid = new PacmanElement[0,0];
    }

    //<Ygibeau>
    /// <summary>
    /// Charge un niveau à partir d'une chaine de caractères en mémoire.
    /// Voir l'énoncé du travail pour le format de la chaîne.
    /// </summary>
    /// <param name="content"> Le contenu du niveau en mémoire</param>
    /// <returns>true si le chargement est correct, false sinon</returns>
    public bool LoadFromMemory(string content)
    {
      bool retval = true;
      string[] extractLine;
      int line = 0;
      extractLine = content.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
      string[] extractSingle;
      if (extractLine.Length == 22)
      {
        grid = new PacmanElement[22, 21];
        for (int i = 0; i < extractLine.Length; i++)
        {
          extractLine[i] = extractLine[i].Trim('\n', '\r', ' ');
          extractSingle = extractLine[i].Split(',');
          if (extractSingle.Length == 21)
          {
            for (int j = 0; j < extractSingle.Length; j++)
            {
              
              grid[line, j] = (PacmanElement)Int32.Parse(extractSingle[j]);
              if (extractSingle[j] == "6")
              {
                if (positionCageFantome.X != -1)
                {
                  retval = false;
                  break;
                }
                positionCageFantome = new Vector2i(line, j);
              }
              if (extractSingle[j] == "3")
              {
                if (positionPacman.X != -1)
                {
                  retval = false;
                  break;
                }
                positionPacman = new Vector2i(j, line);
              }
            }
            line++;
          }
          else
          {
            retval = false;
            break;
          }
        }
      }
      else
      {
        retval = false;
      }
      if (positionPacman.X == -1 || positionCageFantome.X == -1)
      {
        retval = false;
      }
      return retval;
    }
    //</YGibeau>

    /// <summary>
    /// Retourne l'élément à la position spécifiée
    /// </summary>
    /// <param name="row">La ligne</param>
    /// <param name="column">La colonne</param>
    /// <returns>L'élément à la position spécifiée</returns>
    public PacmanElement GetGridElementAt(int row, int column)
    {
      if (row<0 || row>=Height || column<0 || column>=Width)
      {
        throw new ArgumentOutOfRangeException();
      }
      else
      {
        return grid[row, column];
      }      
    }




    /// <summary>
    /// Modifie le contenu du tableau à la position spécifiée
    /// </summary>
    /// <param name="row">La ligne</param>
    /// <param name="column">La colonne</param>
    /// <param name="element">Le nouvel élément à spécifier</param>
    public void SetGridElementAt(int row, int column, PacmanElement element)
    {
      if (row < 0 || row >= Height || column < 0 || column >= Width)
      {
        throw new ArgumentOutOfRangeException();
      }
      else
      {
        grid[row, column] = element;
      }
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace TP3
{
  /// <summary>
  /// Classe représentant les étoiles du fond d'écran
  /// de la fenêtre de jeu
  /// </summary>
  public class Star
  {
    /// <summary>
    /// La largeur de la forme représentant l'objet
    /// </summary>
    public const int STAR_WIDTH = 4;

    /// <summary>
    /// La hauteur de la forme représentant l'objet
    /// </summary>
    public const int STAR_HEIGHT = 4;

    /// <summary>
    /// La vitesse de l'étoile. Instancié
    /// uniquement dans le constructeur
    /// </summary>
    public float Speed { get; private set; }

    /// <summary>
    /// La position en x de l'étoile
    /// </summary>
    public float PositionX { get; private set; }

    /// <summary>
    /// La position en y de l'étoile
    /// </summary>
    public float PositionY { get; private set; }

    /// <summary>
    /// Tous les couleurs qu'une étoile peut être
    /// </summary>
    readonly Color[] colors = new Color[3] { Color.White, Color.Yellow, Color.Cyan };

    /// <summary>
    /// Index de la couleur à utiliser
    /// </summary>
    int colorType;

    /// <summary>
    /// Random qui permet de changer de façon aléatoire 
    /// la couleur de l'étoile
    /// </summary>
    static Random rnd = new Random();

    /// <summary>
    /// La forme de l'étoile
    /// </summary>
    RectangleShape shape = new RectangleShape(new Vector2f(STAR_WIDTH, STAR_HEIGHT));

    /// <summary>
    /// Constructeur qui set le speed et la posisiton de l'étoile
    /// </summary>
    /// <param name="posX">Entier représentant la position initiale en x de l'étoile</param>
    /// <param name="posY">Entier représentant la position initiale en y de l'étoile</param>
    /// <param name="speed">Entier représentant la vitesse de l'étoile</param>
    public Star(float posX, float posY, float speed)
    {
      Speed = speed;
      PositionX = posX;
      PositionY = posY;
    }

    /// <summary>
    /// Afficher l'étoile et changer sa couleur
    /// </summary>
    /// <param name="window">La fenêtre où on affiche l'étoile</param>
    public void Draw(RenderWindow window)
    {
      shape.Position = new Vector2f(PositionX, PositionY);
      colorType = rnd.Next(0, colors.Length);
      shape.FillColor = colors[colorType];
      window.Draw(shape);
    }

    /// <summary>
    /// Mettre à jour la position de l'étoile
    /// </summary>
    /// <param name="deltaT">Le temps en seconde écoulé depuis la dernière mise à jour</param>
    /// <param name="direction">La direction des étoiles</param>
    public void Update(float deltaT, Vector2f direction)
    {
      if (deltaT > 0)
      {
        PositionX = PositionX + direction.X * Speed * deltaT;
        PositionY = PositionY + direction.Y * Speed * deltaT;
        Respawn();
      }
      else
      {
        throw new Exception("deltaT invalid exception");
      }
    }

    /// <summary>
    /// Quand une étoile sort du jeu, on la 
    /// réaffiche à la position opposée
    /// </summary>
    public void Respawn()
    {
      if (PositionX < 0)
      {
        PositionX = GW.WIDTH;
      }
      if (PositionY < 0)
      {
        PositionY = GW.HEIGHT;
      }
      if (PositionX > GW.WIDTH)
      {
        PositionX = 0;
      }
      if (PositionY > GW.HEIGHT)
      {
        PositionY = 0;
      }
    }
  }
}

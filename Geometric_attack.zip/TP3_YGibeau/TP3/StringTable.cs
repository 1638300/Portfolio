﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TP3
{
  /// <summary>
  /// Classe qui permet d'afficher le contenu 
  /// d'un fichier texte selon la langue et
  /// la clé des mots désirées
  /// </summary>
  public class StringTable
  {
    /// <summary>
    /// L'instance de la StringTable active
    /// </summary>
    public static StringTable instance = null;

    /// <summary>
    /// Le dictionnaire qui contient tous 
    /// les autres dictionnaires selon leur langue
    /// </summary>
    private Dictionary<Language, Dictionary<string, string>> langueDictionary = new Dictionary<Language, Dictionary<string, string>>();

    /// <summary>
    /// Instancier une StringTable
    /// s'il n'en a pas encore (singleton). Retourne l'instance 
    /// </summary>
    /// <returns>L'instance du StringTable</returns>
    public static StringTable GetInstance()
    {
      if (instance == null)
      {
        instance = new StringTable();
      }
      return instance;
    }

    /// <summary>
    /// Constructeur private pour contrôler l'instantiation (singleton)
    /// </summary>
    private StringTable()
    {

    }  

    /// <summary>
    /// Diviser un fichier en dictionnaire de langue
    /// et en mots accessibles dans un dictionnaire avec un ID
    /// </summary>
    /// <param name="fileLocation">String représentant la location di fichier à lire</param>
    /// <returns>Un ErrorCode représentant le résultat de la lecture 
    /// et de l'enregistement des informations du fichier</returns>
    public ErrorCode Parse(string fileLocation)
      {
      langueDictionary = new Dictionary<Language, Dictionary<string, string>>();
      //source : https://docs.microsoft.com/en-us/dotnet/api/system.io.streamreader?view=netframework-4.7
      //source : http://stackoverflow.com/questions/105372/how-do-i-enumerate-an-enum
      foreach (Language langue in Enum.GetValues(typeof(Language)))
      {
        langueDictionary.Add(langue, new Dictionary<string, string>());
      }
      try
      {
        using (StreamReader stream = new StreamReader(fileLocation))
        {
          string line;
          try
          {
            int nbMots = 0;
            //Prendre chaque ligne du fichier et l'insérer dans le dictionnaire
            while ((line = stream.ReadLine()) != null)
            {
              int indexKey = line.IndexOf("==>");
              //s'il n'a pas de ==>
              if (indexKey == -1)
              {
                return ErrorCode.BAD_FILE_FORMAT;
              }
              //S'il n'a pas de key avant ==>
              else if (indexKey == 0)
              {
                return ErrorCode.MISSING_FIELD;
              }
              string key = line.Substring(0, indexKey);
              //Début du mot à mettre dans le dictionnaire
              int indexWords = indexKey + 3;
              //Index de la langue
              int langueIndex = 0;
              //Fin du mot à mettre dans le dictionnaire
              int indexWordsEnd = 0;
              //Va chercher le prochain mot de la liste de mots (exemple, si il aurait 4 mots...)
              //source : http://stackoverflow.com/questions/23633861/get-index-of-next-same-character
              while ((indexWordsEnd = line.IndexOf("---", indexWords)) != -1)
              {
                //Extrait le mot et vérifier s'il n'est pas vide
                string addWord = line.Substring(indexWords, indexWordsEnd - indexWords);
                if (addWord == "")
                {
                  return ErrorCode.MISSING_FIELD;
                }
                langueDictionary[(Language)langueIndex].Add(key, addWord);
                //Prochain début de mot
                indexWords = indexWordsEnd + 3;
                //On change de langue
                langueIndex++;
              }
              //Implémente le dernier mot dans le dernier dictionnaire de langue (dans ce cas-ci, english dictionnaire)
              indexWordsEnd = line.Length;
              //Extrait le dernier mot et vérifier s'il n'est pas vide
              string addNewWord = line.Substring(indexWords, indexWordsEnd - indexWords);
              if (addNewWord == "")
              {
                return ErrorCode.MISSING_FIELD;
              }
              langueDictionary[(Language)langueIndex].Add(key, addNewWord);
              nbMots++;
              if (langueIndex < Enum.GetNames(typeof(Language)).Length-1)
              {
                return ErrorCode.BAD_FILE_FORMAT;
              }
            }
            //S'il manque de "---"

            //Si le file est empty
            if (nbMots <=0)
            {
              return ErrorCode.MISSING_FIELD;
            }
            //S'il manque des mots
            foreach (KeyValuePair<Language, Dictionary<string,string>> dic in langueDictionary)
            {
              if (dic.Value.Count != nbMots)
              {
                return ErrorCode.MISSING_FIELD;
              }
            }
          }
          catch (IndexOutOfRangeException)
          {
            throw new Exception("Index out of range");
          }
        }
      }
      catch (FileNotFoundException)
      {
        throw new Exception("File not found");
      }
      return ErrorCode.OK;
    }

    /// <summary>
    /// Obtenir la string désirée avec la langue désirée
    /// dans la StringTable
    /// </summary>
    /// <param name="langue">La langue désirée</param>
    /// <param name="key">La key de la string désirée</param>
    /// <returns></returns>
    public string GetValue(Language langue, string key)
    {
      try
      {
        return langueDictionary[langue][key];
      }
      catch (Exception)
      {
        throw new Exception("Invalid key exception");
      }
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
using SFML.Graphics;
namespace TP3
{
  /// <summary>
  /// Classe héritant de la classe Enemy qui représente un Enemy de
  /// type square dans le jeu
  /// </summary>
  public class Square : Enemy
  {
    /// <summary>
    /// La taille de la forme représentant l'objet
    /// </summary>
    const int SQUARE_SIZE = 40;

    /// <summary>
    /// Constante entière représentant la vitesse de rotation 
    /// et de déplacement de l'objet
    /// </summary>
    const int SQUARE_SPEED = 120;

    /// <summary>
    /// Le nombre de point du square pour le dessiner
    /// </summary>
    const int NB_POINT = 4;

    /// <summary>
    /// Initialise un square formé à partir de 4 points, la vitesse de tire, 
    /// le CharacterType et l'angle (direction).
    /// </summary>
    /// <param name="posX">Entier représentant la position en x du square</param>
    /// <param name="posY">Entier représentant la position en y du square</param>
    /// <param name="angle">Entier représentant l'angle initial du square</param>
    public Square(float posX, float posY,float angle)
    :base(posX,posY, NB_POINT, SQUARE_SIZE, Color.Yellow, SQUARE_SPEED, angle)
    {
      Type = CharacterType.Square;
      this[0] = new Vector2f(-SQUARE_SIZE / 2, -SQUARE_SIZE / 2);
      this[1] = new Vector2f(SQUARE_SIZE / 2, -SQUARE_SIZE / 2);
      this[2] = new Vector2f(SQUARE_SIZE / 2, SQUARE_SIZE / 2);
      this[3] = new Vector2f(-SQUARE_SIZE / 2, SQUARE_SIZE / 2);
      FireDelay = 500;
    }

    /// <summary>
    /// Mettre à jour le square pour qu'il s'enligne sur le héro 
    /// et tire et avance vers lui quand il l'est. Sinon, tourne en rond et avance.
    /// Quand il est en train de "spawner", avance uniquement.
    /// </summary>
    /// <param name="deltaT">Le temps en seconde écoulé depuis la dernière mise à jour</param>
    /// <param name="gw">Objet de classe GW représentant le coeur du jeu</param>
    /// <returns>Un booléen qui indique si le cercle tire ou non.</returns>
    public override bool Update(float deltaT, GW gw)
    {
      if (deltaT>0)
      {
        if (!IsSpawning)
        {
          //Si l'angle est plus grand que 360, on le met à 0 pour permettre de le comparer au résultat d'Atan 2
          if (Angle > 360)
          {
            Angle -= 360;
          }
          //Si l'angle est plus petit que -360, on le met à 0 pour permettre de le comparer au résultat d'Atan 2
          if (Angle < -360)
          {
            Angle += 360;
          }
          //Atan entre la position du héro et la position de l'enemie (on forme la base (Hero.GetInstance().Position.X - Position.X) 
          //et la hauteur (Hero.GetInstance().Position.Y - Position.Y) d'un triangle et on calcul le Tan entre eux)
          float resultatAtan = (float)(Math.Atan2(Hero.GetInstance().Position.Y - Position.Y, Hero.GetInstance().Position.X - Position.X) * 180 / Math.PI);

          //Si le résultat est négatif (triangle est inversé), on fait + 360 pour avoir sa valeur positive
          if (resultatAtan < 0)
          {
            resultatAtan += 360;
          }
          //On laisse un jeu de 10 degrés pour la comparaison entre l'angle actuel de l'enemi et l'angle du Atan
          if (Angle + 5 >= resultatAtan && Angle - 5 <= resultatAtan)
          {
            Angle = resultatAtan;
            Advance(Speed * deltaT);
            if ((DateTime.Now - lastFire).TotalMilliseconds > FireDelay)
            {
              lastFire = DateTime.Now;
              return true;
            }
          }
          //sinon, on cherche à s'enligner sur le héro
          else
          {
            Advance(Speed * deltaT);
            Rotate(Speed * deltaT);
          }
        }
        else
        {
          Advance(Speed * deltaT);
        }
        return false;
      }
      else
      {
        throw new Exception("deltaT invalid exception");
      }
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;
using SFML.System;
namespace TP3
{
  /// <summary>
  /// Un projectile un cube qui 
  /// avance de lui-même dans la 
  /// même direction 
  /// </summary>
  public class Projectile : Movable
  {
    /// <summary>
    /// La vitesse du projectile
    /// </summary>
    const float ProjectileSpeed = 1000;

    /// <summary>
    /// Le type de character qui a
    /// "tiré" le projectile
    /// </summary>
    public CharacterType Type;

    /// <summary>
    /// Instancier le type, l'angle, la position
    /// et les sommets du projectile
    /// </summary>
    /// <param name="Type">Le type de character qui a "tiré" le projectile</param>
    /// <param name="posX">Position en x du projectile</param>
    /// <param name="posY">Position en y du projectile</param>
    /// <param name="nbVertices">Nb de sommets de la forme du projectile</param>
    /// <param name="color">La couleur du projectile</param>
    /// <param name="angle">L'angle (direction) du projectile</param>
    public Projectile(CharacterType Type, float posX, float posY, UInt32 nbVertices,Color color,float angle)
      :base(posX,posY,nbVertices,color, ProjectileSpeed)
    {
      this.Type = Type;
      Angle = angle;
      Position = new Vector2f(posX, posY);
      this[0] = new Vector2f(-3f, -3f);
      this[1] = new Vector2f(-3f, 3f);
      this[2] = new Vector2f(3f, 3f);
      this[3] = new Vector2f(3f, -3f);
    }

    /// <summary>
    /// On avance le projectile à chaque tour et on vérifie s'il est encore dans l'écran du jeu
    /// </summary>
    /// <param name="deltaT">Sert à uniformiser la vitesse des projectiles selon les frames</param>
    /// <param name="gw">Objet de classe GW représentant le coeur du jeu</param>
    /// <returns>Un booléen qui indique si le projectile est encore dans la fenêtre ou non</returns>
    public override bool Update(float deltaT, GW gw)
    {
      if (deltaT > 0)
      {
        Advance(ProjectileSpeed * deltaT);
        return (Position.X < 0 || Position.X > GW.WIDTH || Position.Y < 0 || Position.Y > GW.HEIGHT);
      }
      else
      {
        throw new Exception("deltaT invalid exception");
      }
    }
  }
}

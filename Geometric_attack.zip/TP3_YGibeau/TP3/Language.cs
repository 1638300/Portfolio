﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3
{
  /// <summary>
  /// Tous les langues supportées dans le jeu
  /// </summary>
  public enum Language
  {
    French,
    English
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
using SFML.Graphics;
using SFML.Audio;
namespace TP3
{
  /// <summary>
  /// Classe héritant de la classe Enemy qui représente un Enemy de base du jeu.
  /// Cet ennemi "spawn" uniquement lors de la mort des autres classes qui héritent
  /// de enemy.
  /// </summary>
  public class BasicEnemy : Enemy
  {
    /// <summary>
    /// Constante entière représentant la vitesse de rotation 
    /// et de déplacement de l'objet
    /// </summary>
    const int BASICENEMY_SPEED = 180;

    /// <summary>
    /// La taille de la forme représentant l'objet
    /// </summary>
    const int BASICENEMY_SIZE = 15;

    /// <summary>
    /// Le nombre de point du triangle pour le dessiner
    /// </summary>
    const int NB_SOMMETS = 3;
    /// <summary>
    /// Initialise un triangle équilatéral, la vitesse de tire, le CharacterType 
    /// et l'angle (direction).
    /// </summary>
    /// <param name="posX">Entier représentant la position en x du basicEnemy</param>
    /// <param name="posY">Entier représentant la position en y du basicEnemy</param>
    /// <param name="angle">Entier représentant l'angle initial du basicEnemy</param>
    public BasicEnemy(float posX, float posY, float angle)
      :base(posX,posY, NB_SOMMETS, BASICENEMY_SIZE, new Color(255, 146, 72),BASICENEMY_SPEED, angle)
    {
      Type = CharacterType.BasicEnemy;
      this[0] = new Vector2f(BASICENEMY_SIZE, 0);
      this[1] = new Vector2f(-BASICENEMY_SIZE, -BASICENEMY_SIZE / 2);
      this[2] = new Vector2f(-BASICENEMY_SIZE, BASICENEMY_SIZE / 2);
      FireDelay = 1500;
      Angle = angle;

    }
    /// <summary>
    /// Mettre à jour le BasicEnemy pour qu'il s'enligne sur le héro 
    /// et avance vers lui quand il l'est. Sinon, tourne en rond et avance.
    /// Quand il est en train de "spawner", avance uniquement.
    /// </summary>
    /// <param name="deltaT">Le temps en seconde écoulé depuis la dernière mise à jour</param>
    /// <param name="gw">Objet de classe GW représentant le coeur du jeu</param>
    /// <returns>Un booléen qui indique si le basicEnemy tire ou non. Toujours false (non)</returns>
    public override bool Update(float deltaT, GW gw)
    {
      if (deltaT > 0)
      {
        if (!IsSpawning)
        {
          //Si l'angle est plus grand que 360, on le met à 0 pour permettre de le comparer au résultat d'Atan 2
          if (Angle > 360)
          {
            Angle -= 360;
          }
          //Si l'angle est plus petit que -360, on le met à 0 pour permettre de le comparer au résultat d'Atan 2
          if (Angle < -360)
          {
            Angle += 360;
          }
          //Atan entre la position du héro et la position de l'enemie (on forme la base (Hero.GetInstance().Position.X - Position.X) 
          //et la hauteur (Hero.GetInstance().Position.Y - Position.Y) d'un triangle et on calcul le Tan entre eux)
          float resultatAtan = (float)(Math.Atan2(Hero.GetInstance().Position.Y - Position.Y, Hero.GetInstance().Position.X - Position.X) * 180 / Math.PI);
          //Si le résultat est négatif (triangle est inversé), on fait + 360 pour avoir sa valeur positive
          if (resultatAtan < 0)
          {
            resultatAtan += 360;
          }
          //On laisse un jeu de 10 degrés pour la comparaison entre l'angle actuel de l'enemi et l'angle du Atan
          if (Angle + ECART_ANGLE >= resultatAtan && Angle - ECART_ANGLE <= resultatAtan)
          {
            Angle = resultatAtan;
            Advance(Speed * deltaT);
          }
          //Sinon, on tente de s'enligner en tournant
          else
          {
            Advance(Speed * deltaT);
            Rotate(Speed * deltaT);
          }
        }
        //Si on est en train de "spawner", on avance droit.
        else
        {
          Advance(Speed * deltaT);
        }
        //On ne tire jamais avec le basicEnemy
        return false;
       }
       else
       {
        throw new Exception("deltaT invalid exception");
       }
     }
   }
 }

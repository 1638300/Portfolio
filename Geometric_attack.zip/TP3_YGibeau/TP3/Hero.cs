﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using SFML.Audio;
namespace TP3
{
  /// <summary>
  /// Les héro du jeu (le personnage que le joueur contrôle) qui hérite de character.
  /// Utilise l'interaction utilisateur/programme.
  /// </summary>
  public class Hero : Character
  {
    /// <summary>
    /// Vitesse de déplacement et rotation du héro (en pixel)
    /// </summary>
    public const int HeroSpeed = 5;

    /// <summary>
    /// Indique si le Hero est en vie (quand il a plus que 0 de vie)
    /// </summary>
    public override bool IsAlive {get { return Life > 0; } }

    /// <summary>
    /// La vie du joueur
    /// </summary>
    public int Life = LIFE_AT_BEGINNING;

    /// <summary>
    /// Le size de la forme du Hero dans le jeu
    /// </summary>
    const int HERO_SIZE = 20;

    /// <summary>
    /// La vie du Hero au début
    /// </summary>
    public const int LIFE_AT_BEGINNING = 15000;

    /// <summary>
    /// La couleur du Hero
    /// </summary>
    private readonly Color HeroColor = Color.Blue;

    /// <summary>
    /// Le nombre de bombe du Hero
    /// </summary>
    private int nbBombs = 4;

    /// <summary>
    /// Le temps où la dernière bombe a été utilisée
    /// </summary>
    DateTime lastBomb = DateTime.MinValue;

    /// <summary>
    /// Le délai entre chaque bombe
    /// </summary>
    const int bombDelay = 5000;

    /// <summary>
    /// L'instance du Hero (singleton)
    /// </summary>
    static Hero instance = null;

    /// <summary>
    /// Le son que fait l'explosion d'une bombe
    /// </summary>
    private Music soundBomb = new Music("Data\\Fire_smartbomb.wav");

    /// <summary>
    /// Obtenir l'instance du Hero.
    /// On veut qu'une seule instance Hero 
    /// </summary>
    /// <returns>Retourne l'instance</returns>
    public static Hero GetInstance()
    {
      if (instance == null)
      {
        instance = new Hero(GW.WIDTH / 2, GW.HEIGHT / 2);
      }
      return instance;
    }

    /// <summary>
    /// Constructeur private, car on veut contrôler l'instatiation
    /// d'objets de classe "Hero"
    /// Initialise un triangle équilatéral, la vitesse de tire et le CharacterType
    /// </summary>
    /// <param name="posX">Entier représentant la position en x du héro</param>
    /// <param name="posY">Entier représentant La position en y du héro</param>
    private Hero(float posX, float posY)
    :base(posX,posY,3, Color.Magenta,HeroSpeed)
    {
      this[0] = new Vector2f(HERO_SIZE, 0);
      this[1] = new Vector2f(-HERO_SIZE, -HERO_SIZE/2);
      this[2] = new Vector2f(-HERO_SIZE, HERO_SIZE/2);
      Type = CharacterType.Hero;
      FireDelay = 200;
    }

    /// <summary>
    /// Mettre à jour l'instance Hero dépendamment de les touches 
    /// que l'utilisateur appuient
    /// </summary>
    /// <param name="deltaT">Le temps en seconde écoulé depuis la dernière mise à jour</param>
    /// <param name="gw">Objet de classe GW représentant le coeur du jeu</param>
    /// <returns>Un booléen qui indique si le Hero tire ou non.</returns>
    public override bool Update(float deltaT, GW gw)
    {
      if (deltaT > 0)
      {
          //Tirer bombe seulement si le délai est respecté
          if (Keyboard.IsKeyPressed(Keyboard.Key.B) && nbBombs > 0 && (DateTime.Now - lastBomb).TotalMilliseconds > bombDelay)
        {
            nbBombs--;
            lastBomb = DateTime.Now;
            soundBomb.Play();
            gw.AddBomb();
        }
        //Avance
        if (Keyboard.IsKeyPressed(Keyboard.Key.W))
        {
            Advance(HeroSpeed);
        }
        //Rotate à gauche
        if (Keyboard.IsKeyPressed(Keyboard.Key.A))
        {
          Rotate(-HeroSpeed);
        }
        //Recule
        if (Keyboard.IsKeyPressed(Keyboard.Key.S))
        {
          Advance(-HeroSpeed);
        }
        //Rotate à droite
        if (Keyboard.IsKeyPressed(Keyboard.Key.D))
        {
          Rotate(HeroSpeed);
        }

        //Tirer projectile seulement si le délai est respecté
        if (Keyboard.IsKeyPressed(Keyboard.Key.Space) && (DateTime.Now - lastFire).TotalMilliseconds > FireDelay)
        {
          lastFire = DateTime.Now;
          return true;
        }
        return false;
        }
       else
       {
        throw new Exception("deltaT invalid exception");
      }
    }
  }
}

﻿using System;
using System.IO;
using SFML;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using SFML.Audio;
using System.Collections.Generic;
namespace TP3
{
  /// <summary>
  /// Le coeur du programme : lie tout ensemble pour permettre
  /// au jeu de fonctionner.
  /// </summary>
  public class GW
  {
    // Constantes et propriétés statiques
    /// <summary>
    /// La largeur de la fenêtre de l'application
    /// </summary>
    public const int WIDTH = 1024;

    /// <summary>
    /// La hauteur de la fenêtre de l'application
    /// </summary>
    public const int HEIGHT = 768;

    /// <summary>
    /// Le délai entre l'apparition d'ennemis
    /// </summary>
    const int SPAWN_DELAY = 1000;
   
    /// <summary>
    /// Le temps à l'ouverture du jeu.
    /// </summary>
    static DateTime StartTime = DateTime.Now;

    /// <summary>
    /// Limite du nombre de frame de l'application
    /// </summary>
    public const uint FRAME_LIMIT = 60;
   
    /// <summary>
    /// Un random pour obtenir des valeurs aléatoires
    /// </summary>
    private static Random r = new Random();

    // SFML
    RenderWindow window = null;
    Font font = new Font("Data/emulogic.ttf");
    Text text = null;

    // Propriétés pour la partie
    /// <summary>
    /// Temps écoulé depuis le début de la partie.
    /// </summary>
    TimeSpan totalTime = (DateTime.Now - StartTime);
    
    /// <summary>
    /// Indique la dernière fois où une action délaie
    /// le prochain spawn d'ennemis
    /// </summary>
    DateTime DelayingNextSpawn = DateTime.MinValue;

    /// <summary>
    /// La liste de tous les projectiles actifs du jeu
    /// </summary>
    List<Projectile> projectiles = new List<Projectile>();

    /// <summary>
    /// La liste de tous les ennemis dans le jeu
    /// </summary>
    List<Character> Enemies = new List<Character>();

    /// <summary>
    /// La liste de tous les étoiles du jeu
    /// </summary>
    List<Star> stars = new List<Star>();


    const float DELTA_T = 1.0f / (float)FRAME_LIMIT;

    /// <summary>
    /// Le langage actif du texte à afficher
    /// </summary>
    Language CurrentLanguage = Language.French;

    /// <summary>
    /// Assesseur qui retourne l'instance du Hero
    /// </summary>
    public Hero HeroInstance { get { return Hero.GetInstance(); } }

    private void OnClose(object sender, EventArgs e)
    {
      RenderWindow window = (RenderWindow)sender;
      window.Close();
    }
    
    /// <summary>
    /// Changer la fenêtre en fonction de la 
    /// touche appuyé par l'utilisateur
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnKeyPressed(object sender, KeyEventArgs e)
    {
      if (Keyboard.IsKeyPressed(Keyboard.Key.Escape))
      {
        window.Close();
      }
      if (Keyboard.IsKeyPressed(Keyboard.Key.F4))
      {
        CurrentLanguage = Language.French;
      }
      if (Keyboard.IsKeyPressed(Keyboard.Key.F5))
      {
        CurrentLanguage = Language.English;
      }
    }

    /// <summary>
    /// Constructeur qui set la fenêtre et les étoiles
    /// </summary>
    public GW()
    {
      text = new Text("", font); 
      window = new RenderWindow(new SFML.Window.VideoMode(WIDTH, HEIGHT), "GW");
      window.Closed += new EventHandler(OnClose);
      window.KeyPressed += new EventHandler<KeyEventArgs>(OnKeyPressed);
      window.SetKeyRepeatEnabled(false);
      window.SetFramerateLimit(FRAME_LIMIT);
      for (int i = 0; i < 100; i++)
      {
        stars.Add(new Star(r.Next(1, WIDTH), r.Next(1, HEIGHT), r.Next(100, 300)));
      }

    }

    /// <summary>
    /// Activer la fenêtre et le StringTable
    /// </summary>
    public void Run()
    {
      // ppoulin
      // Chargement de la StringTable. A décommenter au moment opportun
      if (ErrorCode.OK == StringTable.GetInstance().Parse("Data/st.txt"))
      {
        window.SetActive();
        
        while (window.IsOpen)
        {
          window.Clear(Color.Black);
          window.DispatchEvents();
          if (false == Update())
            break;
          Draw();
          window.Display();
        }
      }
    }
    
    /// <summary>
    /// Afficher à l'écran tous les éléments du jeu
    /// </summary>
    public void Draw()
    {
      // Parcourez les listes appropriées pour faire afficher les éléments demandés.
      HeroInstance.Draw(window);
      foreach (Enemy character in Enemies)
      {
        character.Draw(window);
      }
      foreach (Projectile projectile in projectiles)
      {
        projectile.Draw(window);
      }
      foreach (Star star in stars)
      {
        star.Draw(window);
      }
      // Affichage des statistiques. A décommenter au moment opportun
      // Temps total
      text.Position = new Vector2f(0, 10);
      text.DisplayedString = string.Format("{1} = {0,-5}", ((int)(totalTime).TotalSeconds).ToString(), StringTable.GetInstance().GetValue(CurrentLanguage, "ID_TOTAL_TIME"));
      window.Draw(text);

      // Points de vie
      text.Position = new Vector2f(0, 50);
      text.DisplayedString = string.Format("{1} = {0,-4}", HeroInstance.Life.ToString(), StringTable.GetInstance().GetValue(CurrentLanguage, "ID_LIFE"));
      window.Draw(text);
    }
    
    /// <summary>
    /// Spawner des enemies de type aléatoire (circle ou square) 
    /// et à une position aléatoire sur un côté de la fenêtre
    /// </summary>
    /// <param name="nbEnemies">Entier représentant le nombre d'enemies à spawner</param>
    private void SpawnEnemies(int nbEnemies)
    {
      
      for (int i = 0; i < nbEnemies; i++)
      {
        int posY = 0;
        int posX = 0;
        float angle = 0;
        int posi = r.Next(0, 4);
        if (posi == 0)//haut
        {
          angle = 90; //vers le bas
          posY = 0;
          posX = r.Next(0, GW.WIDTH);
        }
        else if (posi == 1)//droite
        {
          angle = 180;//gauche
          posX = GW.WIDTH;
          posY = r.Next(0, GW.HEIGHT);
        }
        else if (posi == 2)//bas
        {
          angle = 270; //haur
          posY = GW.HEIGHT;
          posX = r.Next(0, GW.WIDTH);
        }
        else if (posi == 3)//gauche
        {
          angle = 0;//droite
          posX = 0;
          posY = r.Next(0, GW.HEIGHT);
        }
        if (r.Next(0, 2) == 0)
        {
          Enemies.Add(new Square(posX, posY, angle));
        }
        else
        {
          Enemies.Add(new Circle(posX, posY, angle));
        }
      }
    }

    /// <summary>
    /// "Exploser" une bombe, détruisant tous les enemies actifs
    /// </summary>
    public void AddBomb()
    {
      List<Character> enemyToRemove = new List<Character>();
      foreach (Enemy enemy in Enemies)
      {
        enemyToRemove.Add(enemy);
      }
      foreach (Enemy enemy in enemyToRemove)
      {
        Enemies.Remove(enemy);
      }
      DelayingNextSpawn = DateTime.Now;
    }

    /// <summary>
    /// Mettre à jour tous les éléments actifs du jeu,
    /// les collisions check et le spawn potentiel de 
    /// nouveaux enemies
    /// </summary>
    /// <returns>Un booléen indiquant si le Hero est encore en vie ou non</returns>
    public bool Update()
    {
      #region Init
      // Création des listes de projectiles/enemies à ajouter/enlever
      List<Projectile> projectliesToAdd = new List<Projectile>();
      List<Projectile> projectliesToRemove = new List<Projectile>();
      List<Character> enemyToRemove = new List<Character>();
      List<Character> enemyToAdd = new List<Character>();
      #endregion
      #region Utilisation des bombes
      // Voir AddBomb
      #endregion
      #region Updates
      // Étoiles      
      foreach (Star star in stars)
      {
        star.Update(DELTA_T, -HeroInstance.Direction);
      }

      // Enemies
      foreach (Enemy enemy in Enemies)
      {
        if(enemy.Update(DELTA_T, this))
        {
          enemy.Fire(this);
        }
      }

      //Hero
      if (HeroInstance.Update(DELTA_T, this))
      {
        HeroInstance.Fire(this);    
      }

      //Projectiles
      foreach (Projectile projectile in projectiles)
      {
        if (projectile.Update(DELTA_T,this))
        {
          projectliesToRemove.Add(projectile);
        }
      }
      #endregion
      #region Gestion des collisions
      foreach (Enemy enemy in Enemies)
      {
        foreach (Projectile projectile in projectiles)
        {
          //Entre projectile enemy sur hero
          if (projectile.Type != CharacterType.Hero)
          {
            //S'il y a collision...
            if (HeroInstance.Contains(projectile))
            {
              //On retire le projectile
              projectliesToRemove.Add(projectile);

              //Hero perd 5 de vie
              HeroInstance.Life -= 5;
            }
          }
          //Entre projectile hero sur enemy
          else if (projectile.Type == CharacterType.Hero)
          {
            //S'il y a collision...
            if (enemy.Contains(projectile))
            {
              //On retire l'enemy
              enemyToRemove.Add(enemy);

              //On retire le projectile
              projectliesToRemove.Add(projectile);
            }
          }

          //Entre un Enemy et le Hero
          if (HeroInstance.Intersects(enemy))
          {
            //On retire l'enemy
            enemyToRemove.Add(enemy);

            //Hero perd 10 de vie
            HeroInstance.Life -= 10;
          }
        }
      }
      #endregion           
      #region Retraits
      // Retrait des ennemis détruits et des projectiles inutiles
      //Projectiles
      foreach (Projectile projectile in projectliesToRemove)
      {
        projectiles.Remove(projectile);
      }

      //Enemies
      foreach (Enemy enemy in enemyToRemove)
      {
        Enemies.Remove(enemy);
        if (enemy.Type != CharacterType.BasicEnemy)
        {
          //Quand un enemy meurt, on attend avant d'en spawner d'autres
          DelayingNextSpawn = DateTime.Now;

          //On spawn 4 objets BasicEnemy dans 4 directions différentes
          for (int i = 0; i < 4; i++)
          {
            enemyToAdd.Add(new BasicEnemy(enemy.Position.X, enemy.Position.Y, 90 * i));
          }
        }
      }
      #endregion
      #region Spawning des nouveaux ennemis
      //On ajoute les BasicEnemy
      foreach (Enemy enemy in enemyToAdd)
      {
        Enemies.Add(enemy);
      }
      // On ajoute des enemies seulement si le délai est respecté
      if ((DateTime.Now - DelayingNextSpawn).TotalMilliseconds > SPAWN_DELAY)
      {
        int nbEnemies = 0;

        //Pour chaque Enemy qui n'est pas un BasicEnemy, on compte +1
        foreach (Enemy character in Enemies)
        {
          if (character.Type != CharacterType.BasicEnemy)
          {
            nbEnemies++;
          }
        }

        //Si le compteur est plus bas que 5, on spawn la différence
        if (nbEnemies < 5)
        {
          SpawnEnemies(5 - nbEnemies);
        }
      }
      #endregion
      #region Ajouts
      //On update le temps à afficher à l'écran
      totalTime = (DateTime.Now - StartTime);
      #endregion
      // Retourner true si le héros est en vie, false sinon.
      return HeroInstance.IsAlive;
    }

    /// <summary>
    /// Permettre l'ajout d'un projectile en dehors de la classe
    /// </summary>
    /// <param name="e">Le projectile à ajouter</param>
    public void AddProjectile(Projectile e)
    {
      projectiles.Add(e);
    }
  }
}

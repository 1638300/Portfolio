﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;
using SFML.Audio;
using SFML.System;

namespace TP3
{
  /// <summary>
  /// Un character est un objet qui peut faire 
  /// diverses actions de lui-même
  /// </summary>
  public abstract class Character : Movable
  {
    /// <summary>
    /// Le type de personnage.
    /// </summary>
    public CharacterType Type { get; protected set; }

    private Music fireSound = new Music("Data\\Fire_normal.wav");

    /// <summary>
    /// Vitesse de tire du personnage. En secondes.
    /// </summary>
    protected double FireDelay = 100;

    /// <summary>
    /// Dernier moment où ele personnage a lancé un projectile.
    /// Pour éviter que les personnages lancent sans arrêt .
    /// </summary>
    protected DateTime lastFire = DateTime.MinValue;

    /// <summary>
    /// Constructeur. Protégé car on ne veut pas pouvoir créer de personnage à l'extérieur de la classe,
    /// sauf dans les classes dérivées.
    /// </summary>
    /// <param name="posX">Position en x du character</param>
    /// <param name="posY">Position en y du character</param>
    /// <param name="nbVertices">Nb de sommets de la forme du character</param>
    /// <param name="color">La couleur du character</param>
    /// <param name="speed">La vitesse du character</param>
    protected Character(float posX, float posY, uint nbVertices, Color color, float speed)
      : base(posX, posY, nbVertices, color, speed)
    {
      
    }
    
    /// <summary>
    /// Avancer le character comme la base le fait, on ajoute une condition:
    /// on ne peut pas sortir de l'écran de jeu
    /// </summary>
    /// <param name="nbPixels">Le nb de pixels que l'objet avance</param>
    protected override void Advance(float nbPixels)
    {
      if (Position.X + Direction.X * nbPixels > 0 && Position.X + Direction.X * nbPixels < GW.WIDTH && Position.Y + Direction.Y * nbPixels > 0 && Position.Y + Direction.Y * nbPixels < GW.HEIGHT)
      {
        base.Advance(nbPixels);
      }
    }

    /// <summary>
    /// Ajouter un projectile dans le gw.
    /// Bleu et son quand héro,
    /// rouge et sans son sinon.
    /// </summary>
    /// <param name="gw">Objet de classe GW représentant le coeur du jeu</param>
    public virtual void Fire(GW gw)
    {     
      if (Type == CharacterType.Hero)
      {
        gw.AddProjectile(new Projectile(Type, Position.X, Position.Y, 4, Color.Blue, Angle));
        fireSound.Play();
      }
      else
      {
        gw.AddProjectile(new Projectile(Type, Position.X, Position.Y, 4, Color.Red, Angle));
      }
    }
  }
}

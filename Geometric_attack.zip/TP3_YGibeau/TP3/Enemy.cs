﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;
using SFML.System;
namespace TP3
{
  /// <summary>
  /// Un enemy du jeu qui oppose le Hero.
  /// Hérite de character
  /// </summary>
  public abstract class Enemy : Character
  {
    /// <summary>
    /// Indique si l'enemy est en train de spawner selon
    /// le temps qu'il s'est écoulé depuis la création de 
    /// celui-ci
    /// </summary>
    public bool IsSpawning { get { return (DateTime.Now - WhenCreated).TotalMilliseconds < 500; } }

    /// <summary>
    /// L'écart d'angle entre l'angle de l'enemy et la direction vers le héro
    /// où on accepte d'enligner l'enemy directement sur le héro
    /// </summary>
    protected const int ECART_ANGLE = 5;

    /// <summary>
    /// Indique quand l'enemy a été créé
    /// </summary>
    DateTime WhenCreated = DateTime.Now;

    /// <summary>
    /// Initial
    /// </summary>
    /// <param name="posX">Position en x de l'Enemy</param>
    /// <param name="posY">Position en y de l'Enemy</param>
    /// <param name="nbVertices">Nb de sommets de la forme de l'Enemy</param>
    /// <param name="color">La couleur de l'Enemy</param>
    /// <param name="speed">La vitesse de l'Enemyr</param>
    /// <param name="size">La grosseur de la forme de l'Enemy</param>
    /// <param name="angle">L'angle (direction) de l'enemy</param>
    public Enemy(float posX, float posY, uint nbVertices,float size, Color color, float speed,float angle)
      :base(posX,posY,nbVertices,color,speed)
    {
      Speed = speed;
      Angle = angle;
    }
  }
}

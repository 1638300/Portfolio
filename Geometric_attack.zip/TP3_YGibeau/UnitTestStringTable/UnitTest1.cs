﻿using System;
using TP3;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestStringTable
{
  [TestClass]
  public class UnitTest1
  {
    #region StringTable
    [TestMethod]
    public void TestStringTableEmptyFile()
    {
      Assert.AreEqual(ErrorCode.MISSING_FIELD, StringTable.GetInstance().Parse("Data//Empty_File.txt"));
    }
    
    [TestMethod]
    public void TestStringTableValidFile()
    {
      Assert.AreEqual(ErrorCode.OK, StringTable.GetInstance().Parse("Data//Valid_File.txt"));
    }

    [TestMethod]
    public void TestStringTableInvalidFormatFile()
    {
      Assert.AreEqual(ErrorCode.BAD_FILE_FORMAT, StringTable.GetInstance().Parse("Data//Invalid_Format_File.txt"));
    }

    [TestMethod]
    public void TestStringTableEmptySpace1()
    {
      Assert.AreEqual(ErrorCode.MISSING_FIELD, StringTable.GetInstance().Parse("Data//Empty_Key_File.txt"));
    }
    [TestMethod]
    public void TestStringTableEmptySpace2()
    {
      Assert.AreEqual(ErrorCode.BAD_FILE_FORMAT, StringTable.GetInstance().Parse("Data//Empty_Word_Divider_File.txt"));
    }

    [TestMethod]
    public void TestStringTableEmptySpace3()
    {
      Assert.AreEqual(ErrorCode.MISSING_FIELD, StringTable.GetInstance().Parse("Data//Empty_Word_File.txt"));
    }
    #endregion
    #region GetValue
    [TestMethod]
    public void TestValidGetValue()
    {
      StringTable.GetInstance().Parse("Data//Valid_File.txt");
      Assert.AreEqual("Vie", StringTable.GetInstance().GetValue(Language.French, "ID_LIFE"));
    }

    [TestMethod]
    [ExpectedException(typeof(Exception), "Invalid key exception")]
    public void TestInvalidGetValue()
    {
      StringTable.GetInstance().Parse("Data//Valid_File.txt");
      StringTable.GetInstance().GetValue(Language.French, "InvalidKey");
    }
    #endregion
  }
}
